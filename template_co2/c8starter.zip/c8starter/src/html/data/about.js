module.exports = {
  title: 'About',
  intro: 'intro text about page here',
  banner: require('./modules/banner1')
}
