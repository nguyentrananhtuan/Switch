module.exports = {
  'title': 'Frontend starter template',
  banner: require('./modules/banner1')
}
